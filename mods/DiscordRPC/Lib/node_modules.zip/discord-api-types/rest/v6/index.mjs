import mod from "./index.js";

export default mod;
export const APIVersion = mod.APIVersion;
export const AllowedMentionsTypes = mod.AllowedMentionsTypes;
export const Locale = mod.Locale;
export const RESTJSONErrorCodes = mod.RESTJSONErrorCodes;
export const Routes = mod.Routes;
