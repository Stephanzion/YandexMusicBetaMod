"use strict";
/**
 * Types extracted from https://discord.com/developers/docs/resources/soundboard
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=soundboard.js.map