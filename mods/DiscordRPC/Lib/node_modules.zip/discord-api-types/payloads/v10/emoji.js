"use strict";
/**
 * Types extracted from https://discord.com/developers/docs/resources/emoji
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=emoji.js.map